package main

import "fmt"

func foo(t T)  { t.a = t.a + 1; t.b = t.b + 1 }
func bar(t *T) { t.a = t.a + 1; t.b = t.b + 1 }

type empty struct{}
type G struct {
	a T
	b int
}
type T struct{ a, b int }

func test2() (int, int) {
	return 1, test()
}
func test3(a, b, c int) int {
	{
		var a int
		fmt.Print(a)
	}
	return a + b + c
}
func test() int {
	return 2
}
func test4(_ int) int {
	_ = test()
	// if _ == _ {
	// 	return -1
	// }
	var glob int
	{
		var glob int
		glob++
	}
	var x int
	if x == 2 {
		var glob bool
		var x, y int = test(), test()
		x = test()
		if glob {
			return 2 + y
		}
		return x
	}
	return glob
}

// func test5() {
// 	var a int
// }

// type T struct{ a, b int }
func main() {
	var x, y = test2()
	// var x, y = 1, 2
	// var a = test2()
	test3(test(), test(), test())
	var t T
	// (2 * 2 * 23)++
	y = y + 1
	t.a = x
	t.a++
	t.b = x
	// (t.b)++
	// fmt.Print(t.a, t.b, "\n")
	// foo(t)
	// fmt.Print(t.a, t.b, "\n")
	// bar(&t)
	// fmt.Print(t.a, t.b, "\n")
}
