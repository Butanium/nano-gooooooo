package main

import "fmt"

func test() int {
	return 1
}

func main() {
	var _, y = test(), test()
	&_ // should fail
	fmt.Print("Hello, world!")
}
