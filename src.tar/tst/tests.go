package main

import "fmt"

type Test struct {
	a int
	b *Test2
}

type Test2 struct {
	x *Test
	s string
	j Test
}

func f(a int, b int, c string) (int, string) {
	fmt.Print(a, b, c)
	return a, c
}

func g() (int, int, string) {
	1
	var gg = 0
	if 2 > 3 {
		var gg = "non"
		fmt.Print(gg)
	}
	gg = 5
	fmt.Print(gg)
	// var ref *int
	// ref = &1
	var s = "uwu"
	if &s == nil {
		return 1, 2, "hello"
	}

	return 5, 4, "oh"

}

func test_wild(o *int) **int {
	return &o
}
func test_wild_call() **int {
	return test_wild(nil)
}

func noo(_ int) int {
	var _ int
	// _++
	return 2
}

func main() {
	// var a, b = f(5, 6, "faux"), 5
	var c Test
	var d Test2
	// if &_ == &_ {
	// 	return
	// }
	// if _ == _ {
	// 	return
	// }
	var e, f int
	var g string
	// var _, _ = f(_, 5+6, _)
	_, _ = f(g())
	g = "oh"
	d.s = "hello"
	c.b = &d
	f = 5
	e = 6
	c.b.x = &c
}
